#/bin/bash
# Randy Larson
# September 3, 2011
dir=/root/lab
if [[ ! -e $dir ]]; then
    mkdir $dir
elif [[ ! -d $dir ]]; then
    echo "$dir already exists but is not a directory" 1>&2
fi
rm -f /root/lab/*.txt
clear
# Creates the correct answers file
echo "Question1: whoami" >> /root/lab/answers.txt
echo "Question2: who" >> /root/lab/answers.txt
echo "Question3: ls" >> /root/lab/answers.txt
echo "Question4: ls -l" >> /root/lab/answers.txt
echo "Question5: ls -a" >> /root/lab/answers.txt
echo "Question6: pwd" >> /root/lab/answers.txt
echo "Question7: touch newfile.txt" >> /root/lab/answers.txt
echo "Question8: mkdir test" >> /root/lab/answers.txt
echo "Question9: cd /" >> /root/lab/answers.txt
echo "Question10: man ls" >> /root/lab/answers.txt
echo "Question11: mv file1.txt file2.txt" >> /root/lab/answers.txt
echo "Question12: rm file3.txt" >> /root/lab/answers.txt
echo "Question13: rm -f *.txt" >> /root/lab/answers.txt
echo "Question14: ." >> /root/lab/answers.txt
echo "Question15: cat file4.txt" >> /root/lab/answers.txt
echo "Question16: file file5" >> /root/lab/answers.txt
echo "Question17: updatedb" >> /root/lab/answers.txt
echo "Question18: locate file1.txt" >> /root/lab/answers.txt
echo "Question19: cd /root" >> /root/lab/answers.txt
echo "Question20: cd /home" >> /root/lab/answers.txt
# ADD NEW QUESTION ANSWERS BELOW; USE THE EXAMPLES ABOVE

# DON'T ADD NEW QUESTION ANSWERS BELOW THIS LINE
# DON'T FORGET TO ADD THE QUESTIONS
#open=\033[4m
#close=\033[0m
echo "" >> /root/lab/answers.txt
touch /root/lab/test-results.txt
clear
echo ""
echo ""
echo "   ############################################################"
echo "   #                                                          #"
echo "   #        LAB EXERCISE FOR FUN AND LEARNING                 #"
echo "   #                                                          #"
echo "   ############################################################" 
echo ""
echo ""
echo -e "   \033[1mYou will be asked TWENTY command line syntax questions\033[0m"
echo -e "   \033[1mJust type the answer for each and press enter to go to the next question\033[0m"
# Reset the terminal
tput sgr0
echo ""
echo ""
echo -n "          Do you want to start? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
tput sgr0
clear
echo ""
echo "QUESTION NUMBER ONE:"
echo " What command would you type to see who you are logged in as?"
echo ""
echo -n "   Type your answer and press enter: "; read a1;
echo "Question1: $a1" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TWO:"
echo " What command would you type to see all users that are logged in?"
echo ""
echo -n "   Type your answer and press enter: "; read a2;
echo "Question2: $a2" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER THREE:"
echo " What command would you type to list files and directories?"
echo ""
echo -n "   Type your answer and press enter: "; read a3;
echo "Question3: $a3" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FOUR:"
echo " What command would you type to list files and directories in the long version, include the switch?"
echo ""
echo -n "   Type your answer and press enter: "; read a4;
echo "Question4: $a4" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FIVE:"
echo " What command would you type to list files and directories that reveals all files, include the switch?"
echo ""
echo -n "   Type your answer and press enter: "; read a5;
echo "Question5: $a5" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER SIX:"
echo " What command would you type to see what directory you are presently in?"
echo ""
echo -n "   Type your answer and press enter: "; read a6;
echo "Question6: $a6" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER SEVEN:"
echo -e " What command and argument would you type to make a new file called \033[4mnewfile.txt?\033[0m"
echo ""
echo -n "   Type your answer and press enter: "; read a7;
echo "Question7: $a7" >> /root/lab/results.txt
#open=\033[4m
#close=\033[0m
clear
echo ""
echo "QUESTION NUMBER EIGHT:"
echo -e " What command and argument would you type to make a new directory called \033[4mtest?\033[0m"
echo ""
echo -n "   Type your answer and press enter: "; read a8;
echo "Question8: $a8" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER NINE:"
echo " What command and argument would you type to go to the root of the filesystem?"
echo ""
echo -n "   Type your answer and press enter: "; read a9;
echo "Question9: $a9" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TEN:"
echo " What command and argument would you type to view the man pages for the command ls?"
echo ""
echo -n "   Type your answer and press enter: "; read a10;
echo "Question10: $a10" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER ELEVEN:"
echo " What command and arguments would you type to rename or move the following file?"
echo -e " You wish to move or rename \033[4mfile1.txt\033[0m to \033[4mfile2.txt\033[0m"
echo ""
echo -n "   Type your answer and press enter: "; read a11;
echo "Question11: $a11" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TWELVE:"
echo -e " What command and arguments would you type to remove a file called \033[4mfile3.txt?\033[0m"
echo ""
echo -n "   Type your answer and press enter: "; read a12;
echo "Question12: $a12" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER THIRTEEN:"
echo " As you have learned, the user root is prompted interactively for file confirmation removal"
echo " The user root could remove files that are critical to the operating system!"
echo -e " The user root desires to remove all files that end in \033[4m.txt\033[0m in the current directory"
echo -e " The user root also desires \033[4mNOT\033[0m to confirm deletion"
echo -e " Type the command and arguments that would \033[4mforceably\033[0m remove all file that end in \033[4m.txt?\033[0m"
echo ""
echo -n "   Type your answer and press enter: "; read a13;
echo "Question13: $a13" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FOURTEEN:"
echo -e " What \033[4msingle character\033[0m when placed as the \033[4mfirst character\033[0m in a filename or directory name will make it \033[4mhidden?\033[0m"
echo " Hint: the ls -a command will reveal the hidden file or directory"
echo ""
echo -n "   Type your answer and press enter: "; read a14;
echo "Question14: $a14" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER FIFTEEN:"
echo " What command and argument would a user type to view the contents inside a file?"
echo -e " The user wants to view the contents \033[4mfile4.txt\033[0m without opening it" 
echo -e " Hint: The command comes from the word \033[4mconcatenate\033[0m"
echo ""
echo -n "   Type your answer and press enter: "; read a15;
echo "Question15: $a15" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER SIXTEEN:"
echo -e " You have discovered a new file on the system called \033[4mfile5\033[0m and not sure if it is a text file"
echo -e " What command and argument would you type to find out if \033[4mfile5\033[0m is a text file?" 
echo ""
echo -n "   Type your answer and press enter: "; read a16;
echo "Question16: $a16" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER SEVENTEEN:"
echo " You need to use the locate command and want to update the locate database first"
echo " What command do you type to update the locate database?" 
echo ""
echo -n "   Type your answer and press enter: "; read a17;
echo "Question17: $a17" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER EIGHTEEN:"
#echo -e "   \033[1mJust type the answer for each and press enter to go to the next question\033[0m"
echo -e " You need to locate a file called \033[4mfile1.txt\033[0m"
echo " What command and argument do you type to find this file?" 
echo ""
echo -n "   Type your answer and press enter: "; read a18;
echo "Question18: $a18" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER NINETEEN:"
echo " What command and argument do you type using the ABSOLUTE path to go to the user root's home directory?" 
echo ""
echo -n "   Type your answer and press enter: "; read a19;
echo "Question19: $a19" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TWENTY (FINAL QUESTION):"
echo " Where is the location of ordinary users home directories by default?"
echo " Type the command, argument and ABSOLUTE path to get to ordinary users home directories"  
echo ""
echo -n "   Type your answer and press enter: "; read a20;
echo "Question20: $a20" >> /root/lab/results.txt
clear
echo ""
# END OW QUESTIONS
# END OW QUESTIONS
########################################
##########END OF LAB EXERCISE###############
echo ""
echo " End of the Lab, press enter to see your results"
read b1
echo "."
sleep .1
clear
echo ".."
sleep .1
clear
echo "..."
sleep .1
clear
echo "...."
sleep .1
clear
echo "....."
sleep .1
clear
echo "......"
sleep .1
clear
echo "......."
sleep .1
clear
echo "........."
sleep .1
clear
echo ".........."
sleep .1
clear
echo "..........."
sleep .1
clear
echo "............"
sleep .1
clear
echo "............."
sleep .1
clear
echo ".............."
sleep .1
clear
echo "..............."
sleep .1
clear
echo "................"
sleep .1
clear
echo "................."
sleep .1
clear
echo ".................."
sleep .1
clear
echo "..................."
sleep .1
clear
echo "...................."
sleep .1
clear
echo "....................."
sleep .1
clear
echo "......................"
sleep .1
clear
echo "......................."
sleep .1
clear
echo "........................"
sleep .1
clear
echo "........................."
sleep .1
clear
echo ".........................."
sleep .1
clear
echo "..........................."
sleep .1
clear
echo "............................"
sleep .1
clear
echo "............................."
sleep .1
clear
echo ".............................."
sleep .1
clear
echo "..............................."
sleep .1
clear
echo "................................"
sleep .1
clear
echo "................................."
sleep .1
clear
echo "...................................YOU SHOULD REPEAT THIS UNTIL YOU GET 100%"
sleep 3
clear
# Begin Grading
diff /root/lab/results.txt /root/lab/answers.txt | grep Question > /root/lab/test-results.txt
file=/root/lab/test-results.txt
echo ""
echo "***********FINAL RESULTS*****************" >> /root/lab/final-results.txt
echo "If the line below is blank, you received 100%, if not review what you missed" >> /root/lab/final-results.txt
echo "___________________________________________________________" >> /root/lab/final-results.txt
echo "" >> /root/lab/final-results.txt
sed -i 's/>/The Correct Answer is:/g' $file
sed -i 's/</Your Incorrect Answer:/g' $file
#sed -i 's/</Your Answer:/g' $file
cat /root/lab/test-results.txt >> /root/lab/final-results.txt
# View Results
cat /root/lab/final-results.txt
echo ""
echo -n "      Would you like to e-mail the results to your instructor? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
# Instructors either change to your e-mail address or root@localhost
echo -n "   Type your First and Last Name, Example: John Doe: "; read flname;
mail -s "$flname" larson@estrellamountain.edu < /root/lab/test-results.txt 
# Begin Date Declaration
a=`date +%b-%d-%Y`
b=`date +%H`
c=`date +%M`
d=`date +%S`
# End Date Declaration
directory=/root/lab/results
if [[ ! -e $directory ]]; then
    mkdir $directory
elif [[ ! -d $directory ]]; then
    echo "$dir already exists but is not a directory" 1>&2
fi
cp /root/lab/test-results.txt /root/lab/results/restults-$a-$b-$c-$d.txt
clear
echo ""
echo "You can view all your past results in /root/lab/results"
echo "Press the enter key to finish with this lab"
read enter
#EOF
