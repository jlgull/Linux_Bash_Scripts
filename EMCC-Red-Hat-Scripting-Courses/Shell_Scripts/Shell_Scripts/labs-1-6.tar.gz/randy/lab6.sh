#/bin/bash
# Randy Larson September 24, 2011
# CIS126DL Workbook Five
dir=/root/lab
if [[ ! -e $dir ]]; then
    mkdir $dir
elif [[ ! -d $dir ]]; then
    echo "$dir already exists but is not a directory" 1>&2
fi
rm -f /root/lab/*.txt
clear
# Creates the correct answers file
echo "Question1: showmount -e 192.168.0.254" >> /root/lab/answers.txt
echo "Question2: mount 192.168.0.254:/var/ftp/pub/ /server1/" >> /root/lab/answers.txt
echo "Question3: mount" >> /root/lab/answers.txt
echo "Question4: umount /server1/" >> /root/lab/answers.txt
echo "Question5: tar -cvf /root/web.tar /var/www/html/" >> /root/lab/answers.txt
echo "Question6: tar -tvf /root/web.tar" >> /root/lab/answers.txt
echo "Question7: tar -xvf /root/web.tar" >> /root/lab/answers.txt
echo "Question8: scp /root/web.tar 192.168.0.254:/var/ftp/pub/" >> /root/lab/answers.txt
echo "Question9: wget ftp://192.168.0.254/pub/web.tar" >> /root/lab/answers.txt
echo "Question10: ln -s /var/www/html/randy/ /home/randy/upload" >> /root/lab/answers.txt
echo "Question11: gzip sales.txt" >> /root/lab/answers.txt
echo "Question12: gunzip sales.txt.gz" >> /root/lab/answers.txt
echo "Question13: updatedb" >> /root/lab/answers.txt
echo "Question14: locate dhcpd.conf" >> /root/lab/answers.txt
echo "Question15: ls -i readme.txt" >> /root/lab/answers.txt
# IMPORTANT CHANGE THE DATA NUMBER BELOW TO MATCH THE NUMBER OF QUESTIONS!
total_ques=15
# ADD NEW QUESTION ANSWERS BELOW; USE THE EXAMPLES ABOVE

# DON'T ADD NEW QUESTION ANSWERS BELOW THIS LINE
# DON'T FORGET TO ADD THE QUESTIONS
#open=\033[4m
#close=\033[0m
echo "" >> /root/lab/answers.txt
touch /root/lab/test-results.txt
clear
echo ""
echo ""
echo "   ############################################################"
echo "   #                                                          #"
echo "   #        LAB EXERCISE FOR FUN AND LEARNING                 #"
echo "   #                                                          #"
echo "   ############################################################" 
echo ""
echo -e "   \033[1mLAB EXERCISE SIX - WORKBOOK FIVE\033[0m"
echo ""
echo -e "   \033[1mYou will be asked FIFTEEN command line syntax questions\033[0m"
echo -e "   \033[1mJust type the answer for each and press enter to go to the next question\033[0m"
echo -e "   \033[1mAlways use the trailing slashes after a directory!\033[0m"
echo -e "   \033[1mUsing trailing slashes helps us distinguish directories from files\033[0m"
echo -e "   \033[1mRemember directories always have a trailing slash\033[0m"
echo -e "   \033[1mFiles never have a trailing slash\033[0m"
# Reset the terminal
tput sgr0
echo ""
echo ""
echo -n "          Do you want to start? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
tput sgr0
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER ONE:"
echo -e " You are currently logged in as the superuser root"
echo -e " You wish to see what filesystem is being exported from: 192.168.0.254"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a1;
echo "Question1: $a1" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TWO:"
echo -e " You are currently logged in as the superuser root"
echo -e " You need to mount a filesystem that is being exported from: 192.168.0.254"
echo -e " The exported directory is /var/ftp/pub/"
echo -e " You desire to mount it to your local directory: /server1/"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a2;
echo "Question2: $a2" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER THREE:"
echo -e " You are currently logged in as the superuser root"
echo -e " You would like to view all current mounts"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a3;
echo "Question3: $a3" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FOUR:"
echo -e " You are currently logged in as the superuser root"
echo -e " You are finished using the mount point: /server1/"
echo -e " You wish to unmount what is being imported to /server1/"
echo -e " Assume no user is in /server1 at this time"
echo ""
echo -n "   Type your answer and press enter: "; read a4;
echo "Question4: $a4" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FIVE:"
echo -e " You are currently logged in as the superuser root"
echo -e " You need to create a tar file in /root/ called: web.tar"
echo -e " The directory you want to tar is /var/www/html/"
echo -e " You could type this command and arguments from anywhere in the filesystem"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a5;
echo "Question5: $a5" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER SIX:"
echo -e " You are currently logged in as the superuser root"
echo -e " You wish to view the contents of the web.tar file using the tar command"
echo -e " The current file location is /root/web.tar"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a6;
echo "Question6: $a6" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER SEVEN:"
echo -e " You are currently logged in as the superuser root"
echo -e " You wish to un-tar the web.tar file"
echo -e " You also don't want to over-write any files"
echo -e " You wish to extract the web.tar file contents in /root/"
echo -e " The current file location is /root/web.tar"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a7;
echo "Question7: $a7" >> /root/lab/results.txt
#open=\033[4m
#close=\033[0m
clear
echo ""
echo "QUESTION NUMBER EIGHT:"
echo -e " You are currently logged in as the superuser root"
echo -e " Yu wish to secure copy the /root/web.tar to 192.168.0.254"
echo -e " The copy target directory on 192.168.0.254 is:/var/ftp/pub/"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a8;
echo "Question8: $a8" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER NINE:"
echo -e " You are currently logged in as the superuser root"
echo -e " You are currently in the /root/ directory"
echo -e " There is a file on 192.168.0.254"
echo -e " The path to this file on 192.168.0.254 is  /var/ftp/pub/web.tar"
echo -e " You wish to use wget to obtain this file to your current directory"
echo -e " The 192.168.0.254 server is using the ftp protocol"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a9;
echo "Question9: $a9" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TEN:"
echo -e " You are currently logged in as the superuser root"
echo -e " You wish to create a symbolic link in the /home/randy/ directory called: upload"
echo -e " You wish to link /var/www/html/randy/ to this symbolic link"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a10;
echo "Question10: $a10" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER ELEVEN:"
echo -e " You are currently logged in as the superuser root"
echo -e " There is a file in your current directory called: sales.txt"
echo -e " You wish to compress this file using gzip"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a11;
echo "Question11: $a11" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TWELVE:"
echo -e " You are currently logged in as the superuser root"
echo -e " There is a file in your current directory called: sales.txt.gz"
echo -e " You wish to uncompress this file using gzip"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a12;
echo "Question12: $a12" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER THIRTEEN:"
echo -e " You are currently logged in as the superuser root"
echo -e " You wish to update the locate database"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a13;
echo "Question13: $a13" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FOURTEEN:"
echo -e " You are currently logged in as the superuser root"
echo -e " You wish to locate a file called: dhcpd.conf"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a14;
echo "Question14: $a14" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FIFTEEN:"
echo -e " You are currently logged in as the superuser root"
echo -e " There is a file in your current directory called: readme.txt"
echo -e " You want to see what inode number this file has assigned to it"
echo -e " You also do not wish to see any other file details"
echo -e " Type the proper command and argument to do this:"
echo ""
echo -n "   Type your answer and press enter: "; read a15;
echo "Question15: $a15" >> /root/lab/results.txt
clear
echo ""
# END OF QUESTIONS
########################################
#######   END OF LAB EXERCISE  #########
echo ""
echo " End of the Lab, press enter to see your results"
read b1
echo "."
sleep .1
clear
echo ".."
sleep .1
clear
echo "..."
sleep .1
clear
echo "...."
sleep .1
clear
echo "....."
sleep .1
clear
echo "......"
sleep .1
clear
echo "......."
sleep .1
clear
echo "........."
sleep .1
clear
echo ".........."
sleep .1
clear
echo "..........."
sleep .1
clear
echo "............"
sleep .1
clear
echo "............."
sleep .1
clear
echo ".............."
sleep .1
clear
echo "..............."
sleep .1
clear
echo "................"
sleep .1
clear
echo "................."
sleep .1
clear
echo ".................."
sleep .1
clear
echo "..................."
sleep .1
clear
echo "...................."
sleep .1
clear
echo "....................."
sleep .1
clear
echo "......................"
sleep .1
clear
echo "......................."
sleep .1
clear
echo "........................"
sleep .1
clear
echo "........................."
sleep .1
clear
echo ".........................."
sleep .1
clear
echo "..........................."
sleep .1
clear
echo "............................"
sleep .1
clear
echo "............................."
sleep .1
clear
echo ".............................."
sleep .1
clear
echo "..............................."
sleep .1
clear
echo "................................"
sleep .1
clear
echo "................................."
sleep .1
clear
echo "...................................YOU SHOULD REPEAT THIS UNTIL YOU GET 100%"
sleep 3
clear
# Begin Grading
diff /root/lab/results.txt /root/lab/answers.txt | grep Question > /root/lab/test-results.txt
file=/root/lab/test-results.txt
echo ""
echo "***********FINAL RESULTS*****************" >> /root/lab/final-results.txt
echo "If the line below is blank, you received 100%, if not review what you missed" >> /root/lab/final-results.txt
echo "___________________________________________________________" >> /root/lab/final-results.txt
echo "" >> /root/lab/final-results.txt
sed -i 's/>/The Correct Answer is:/g' $file
sed -i 's/</Your Incorrect Answer:/g' $file
cat /root/lab/test-results.txt >> /root/lab/final-results.txt
tr -cs 'A-Za-z' '\n' < /root/lab/final-results.txt | grep -c "Incorrect" > /root/lab/data2.txt
echo " You missed:" > /root/lab/data1.txt
paste /root/lab/data1.txt /root/lab/data2.txt > /root/lab/you-missed.txt
echo ""
echo ""
# Begin to Calculate
total_miss=`cat /root/lab/data2.txt`
total_right=$(($total_ques - $total_miss))
total_percent=$(($total_right*100/$total_ques))
max_percent=100
# Begin showing number missed and percentage
echo -n "          Do you want to see your performance? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
echo ""
echo ""
echo "     You got $total_right questions right"
echo "     You got $total_miss questions wrong"
echo "     You received a $total_percent%"
echo ""
if [ "$max_percent" -eq "$total_percent" ]
then
echo "     You have mastered this lab!"
echo "     It still doesn't hurt to keep practicing!"
else
echo "     You received less than 100%"
echo "     You need to practice more."
fi
echo ""
echo ""
echo "Press the enter key to continue"
read enter
echo "You got $total_right questions right" >> /root/lab/final-results.txt
echo "You got $total_miss questions wrong" >> /root/lab/final-results.txt
echo "You revieved a $total_percent%" >> /root/lab/final-results.txt
# Let the user see the questions and answers
echo -n "          Would you like to see the answers? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
cat /root/lab/final-results.txt
echo ""
echo -n "      Would you like to e-mail the results to your instructor? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
# Instructors either change to your e-mail address or root@localhost
echo -n "   Type your First and Last Name, Example: John Doe: "; read flname;
mail -s "$flname" larson@estrellamountain.edu < /root/lab/test-results.txt 
# Begin Date Declaration
a=`date +%b-%d-%Y`
b=`date +%H`
c=`date +%M`
d=`date +%S`
# End Date Declaration
directory=/root/lab/results
if [[ ! -e $directory ]]; then
    mkdir $directory
elif [[ ! -d $directory ]]; then
    echo "$dir already exists but is not a directory" 1>&2
fi
cp /root/lab/test-results.txt /root/lab/results/restults-$a-$b-$c-$d.txt
clear
echo ""
echo "You can view all your past results in /root/lab/results"
echo "Press the enter key to finish with this lab"
read enter
#EOF
