#/bin/bash
# Randy Larson September 14, 2011
# CIS126DL Workbook Four
dir=/root/lab
if [[ ! -e $dir ]]; then
    mkdir $dir
elif [[ ! -d $dir ]]; then
    echo "$dir already exists but is not a directory" 1>&2
fi
rm -f /root/lab/*.txt
clear
# Creates the correct answers file
echo "Question1: 777" >> /root/lab/answers.txt
echo "Question2: 666" >> /root/lab/answers.txt
echo "Question3: 755" >> /root/lab/answers.txt
echo "Question4: 775" >> /root/lab/answers.txt
echo "Question5: 644" >> /root/lab/answers.txt
echo "Question6: 664" >> /root/lab/answers.txt
echo "Question7: chmod 777 install.sh" >> /root/lab/answers.txt
echo "Question8: chmod 666 install.sh" >> /root/lab/answers.txt
echo "Question9: chmod 775 install.sh" >> /root/lab/answers.txt
echo "Question10: chmod 644 install.sh" >> /root/lab/answers.txt
echo "Question11: chmod 664 install.sh" >> /root/lab/answers.txt
echo "Question12: chown dan:dan index.html" >> /root/lab/answers.txt
echo "Question13: chown randy:web index.html" >> /root/lab/answers.txt
echo "Question14: cp index.html /var/www/html/" >> /root/lab/answers.txt
echo "Question15: ls -l /var/www/html/index.html" >> /root/lab/answers.txt
# IMPORTANT CHANGE THE DATA NUMBER BELOW TO MATCH THE NUMBER OF QUESTIONS!
total_ques=15
# ADD NEW QUESTION ANSWERS BELOW; USE THE EXAMPLES ABOVE

# DON'T ADD NEW QUESTION ANSWERS BELOW THIS LINE
# DON'T FORGET TO ADD THE QUESTIONS
#open=\033[4m
#close=\033[0m
echo "" >> /root/lab/answers.txt
touch /root/lab/test-results.txt
clear
echo ""
echo ""
echo "   ############################################################"
echo "   #                                                          #"
echo "   #        LAB EXERCISE FOR FUN AND LEARNING                 #"
echo "   #                                                          #"
echo "   ############################################################" 
echo ""
echo -e "   \033[1mLAB EXERCISE THREE - WORKBOOK THREE\033[0m"
echo ""
echo -e "   \033[1mYou will be asked FIFTEEN command line syntax questions\033[0m"
echo -e "   \033[1mJust type the answer for each and press enter to go to the next question\033[0m"
echo -e "   \033[1mONLY USE OCTAL NOTATIONS!!!!!!!!!\033[0m"
# Reset the terminal
tput sgr0
echo ""
echo ""
echo -n "          Do you want to start? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
tput sgr0
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER ONE:"
echo -e " You are currently /opt directory"
echo -e " There is a child directory present named: temp"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: drwxrwxrwx"
echo -e " WHAT ARE THE OCTAL NUMBER PERMISSIONS?"
echo ""
echo -n "   Type your answer and press enter: "; read a1;
echo "Question1: $a1" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TWO:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: index.html"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rw-rw-rw-"
echo -e " WHAT ARE THE OCTAL NUMBER PERMISSIONS?"
echo ""
echo -n "   Type your answer and press enter: "; read a2;
echo "Question2: $a2" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER THREE:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: rn.sh"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rwxr-xr-x"
echo -e " WHAT ARE THE OCTAL NUMBER PERMISSIONS?"
echo ""
echo -n "   Type your answer and press enter: "; read a3;
echo "Question3: $a3" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FOUR:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: install.sh"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rwxrwxr-x"
echo -e " WHAT ARE THE OCTAL NUMBER PERMISSIONS?"
echo ""
echo -n "   Type your answer and press enter: "; read a4;
echo "Question4: $a4" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FIVE:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: readme.txt"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rw-r--r--"
echo -e " WHAT ARE THE OCTAL NUMBER PERMISSIONS?"
echo ""
echo -n "   Type your answer and press enter: "; read a5;
echo "Question5: $a5" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER SIX:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: release-notes.txt"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rw-rw-r--"
echo -e " WHAT ARE THE OCTAL NUMBER PERMISSIONS?"
echo ""
echo -n "   Type your answer and press enter: "; read a6;
echo "Question6: $a6" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER SEVEN:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: install.sh"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rwxrwxr-x"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO CHANGE THE FILE TO:-rwxrwxrwx?"
echo ""
echo -n "   Type your answer and press enter: "; read a7;
echo "Question7: $a7" >> /root/lab/results.txt
#open=\033[4m
#close=\033[0m
clear
echo ""
echo "QUESTION NUMBER EIGHT:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: install.sh"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rwxrwxrwx"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO CHANGE THE FILE TO:-rw-rw-rw-?"
echo " Hint: This command and argument will also display a plan if they have one"
echo ""
echo -n "   Type your answer and press enter: "; read a8;
echo "Question8: $a8" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER NINE:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: install.sh"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rw-rw-rw-"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO CHANGE THE FILE TO:-rwxrwxr-x?"
echo ""
echo -n "   Type your answer and press enter: "; read a9;
echo "Question9: $a9" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TEN:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: install.sh"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rwxrwxr-x"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO CHANGE THE FILE TO:-rw-r--r--?"
echo ""
echo -n "   Type your answer and press enter: "; read a10;
echo "Question10: $a10" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER ELEVEN:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: install.sh"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following: -rw-r--r--"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO CHANGE THE FILE TO:-rw-rw-r--?"
echo ""
echo -n "   Type your answer and press enter: "; read a11;
echo "Question11: $a11" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER TWELVE:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: index.html"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following:-rw-rw-rw-  1 root root Sep 14 04:37 index.html"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO CHANGE THE FILE'S OWNERSHIP TO BELOW?"
echo -e " -rw-rw-rw-  1 dan dan Sep 14 04:37 index.html"
echo ""
echo -n "   Type your answer and press enter: "; read a12;
echo "Question12: $a12" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER THIRTEEN:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: index.html"
echo -e " You preform an ls -l and it returns the following:"
echo -e " You see the following:-rw-rw-rw-  1 dan dan Sep 14 04:37 index.html"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO CHANGE THE FILE'S OWNERSHIP TO BELOW:?"
echo -e " -rw-rw-rw-  1 randy web Sep 14 04:37 index.html"
echo ""
echo -n "   Type your answer and press enter: "; read a13;
echo "Question13: $a13" >> /root/lab/results.txt
clear
echo ""
echo "QUESTION NUMBER FOURTEEN:"
echo -e " You are currently /opt directory"
echo -e " There is a file named: index.html"
echo -e " You wish to copy the file index.html to the directory listed below:"
echo -e " /var/www/html/"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO PERFORM THIS?"
echo ""
echo -n "   Type your answer and press enter: "; read a14;
echo "Question14: $a14" >> /root/lab/results.txt
clear
#open=\033[4m
#close=\033[0m
echo ""
echo "QUESTION NUMBER FIFTEEN:"
echo -e " You are currently /opt directory"
echo -e " You just copied the file index.html to /var/www/html/"
echo -e " You want to verify the new location file permissions and ownership:"
echo -e " WHAT COMMANDS AND ARGUMENTS WOULD YOU TYPE TO PERFORM THIS USING THE LONG LISTING?"
echo ""
echo -n "   Type your answer and press enter: "; read a15;
echo "Question15: $a15" >> /root/lab/results.txt
clear
echo ""
# END OF QUESTIONS
########################################
#######   END OF LAB EXERCISE  #########
echo ""
echo " End of the Lab, press enter to see your results"
read b1
echo "."
sleep .1
clear
echo ".."
sleep .1
clear
echo "..."
sleep .1
clear
echo "...."
sleep .1
clear
echo "....."
sleep .1
clear
echo "......"
sleep .1
clear
echo "......."
sleep .1
clear
echo "........."
sleep .1
clear
echo ".........."
sleep .1
clear
echo "..........."
sleep .1
clear
echo "............"
sleep .1
clear
echo "............."
sleep .1
clear
echo ".............."
sleep .1
clear
echo "..............."
sleep .1
clear
echo "................"
sleep .1
clear
echo "................."
sleep .1
clear
echo ".................."
sleep .1
clear
echo "..................."
sleep .1
clear
echo "...................."
sleep .1
clear
echo "....................."
sleep .1
clear
echo "......................"
sleep .1
clear
echo "......................."
sleep .1
clear
echo "........................"
sleep .1
clear
echo "........................."
sleep .1
clear
echo ".........................."
sleep .1
clear
echo "..........................."
sleep .1
clear
echo "............................"
sleep .1
clear
echo "............................."
sleep .1
clear
echo ".............................."
sleep .1
clear
echo "..............................."
sleep .1
clear
echo "................................"
sleep .1
clear
echo "................................."
sleep .1
clear
echo "...................................YOU SHOULD REPEAT THIS UNTIL YOU GET 100%"
sleep 3
clear
# Begin Grading
diff /root/lab/results.txt /root/lab/answers.txt | grep Question > /root/lab/test-results.txt
file=/root/lab/test-results.txt
echo ""
echo "***********FINAL RESULTS*****************" >> /root/lab/final-results.txt
echo "If the line below is blank, you received 100%, if not review what you missed" >> /root/lab/final-results.txt
echo "___________________________________________________________" >> /root/lab/final-results.txt
echo "" >> /root/lab/final-results.txt
sed -i 's/>/The Correct Answer is:/g' $file
sed -i 's/</Your Incorrect Answer:/g' $file
cat /root/lab/test-results.txt >> /root/lab/final-results.txt
tr -cs 'A-Za-z' '\n' < /root/lab/final-results.txt | grep -c "Incorrect" > /root/lab/data2.txt
echo " You missed:" > /root/lab/data1.txt
paste /root/lab/data1.txt /root/lab/data2.txt > /root/lab/you-missed.txt
echo ""
echo ""
# Begin to Calculate
total_miss=`cat /root/lab/data2.txt`
total_right=$(($total_ques - $total_miss))
total_percent=$(($total_right*100/$total_ques))
max_percent=100
# Begin showing number missed and percentage
echo -n "          Do you want to see your performance? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
echo ""
echo ""
echo "     You got $total_right questions right"
echo "     You got $total_miss questions wrong"
echo "     You received a $total_percent%"
echo ""
if [ "$max_percent" -eq "$total_percent" ]
then
echo "     You have mastered this lab!"
echo "     It still doesn't hurt to keep practicing!"
else
echo "     You received less than 100%"
echo "     You need to practice more."
fi
echo ""
echo ""
echo "Press the enter key to continue"
read enter
echo "You got $total_right questions right" >> /root/lab/final-results.txt
echo "You got $total_miss questions wrong" >> /root/lab/final-results.txt
echo "You revieved a $total_percent%" >> /root/lab/final-results.txt
# Let the user see the questions and answers
echo -n "          Would you like to see the answers? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
cat /root/lab/final-results.txt
echo ""
echo -n "      Would you like to e-mail the results to your instructor? (Y/N):"; read answer
if test "$answer" != "Y" -a "$answer" != "y";
then exit 0;
fi
# Instructors either change to your e-mail address or root@localhost
echo -n "   Type your First and Last Name, Example: John Doe: "; read flname;
mail -s "$flname" larson@estrellamountain.edu < /root/lab/test-results.txt 
# Begin Date Declaration
a=`date +%b-%d-%Y`
b=`date +%H`
c=`date +%M`
d=`date +%S`
# End Date Declaration
directory=/root/lab/results
if [[ ! -e $directory ]]; then
    mkdir $directory
elif [[ ! -d $directory ]]; then
    echo "$dir already exists but is not a directory" 1>&2
fi
cp /root/lab/test-results.txt /root/lab/results/restults-$a-$b-$c-$d.txt
clear
echo ""
echo "You can view all your past results in /root/lab/results"
echo "Press the enter key to finish with this lab"
read enter
#EOF
