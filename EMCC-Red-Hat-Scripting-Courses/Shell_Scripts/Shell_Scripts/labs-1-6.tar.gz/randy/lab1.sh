#/bin/bash
mkdir /root/lab/
rm -f /root/lab/*.txt
clear
# Creates the correct answers file
echo "CORRECT ANSWERS" >> /root/lab/answers.txt
echo "whoami" >> /root/lab/answers.txt
echo "who" >> /root/lab/answers.txt
echo "ls" >> /root/lab/answers.txt
echo "ls -l" >> /root/lab/answers.txt
echo "ls -a" >> /root/lab/answers.txt
echo "pwd" >> /root/lab/answers.txt
echo "touch newfile.txt" >> /root/lab/answers.txt
echo "mkdir test" >> /root/lab/answers.txt
echo "cd /" >> /root/lab/answers.txt
echo "man ls" >> /root/lab/answers.txt
echo "" >> /root/lab/answers.txt
echo "YOUR ANSWERS" >> /root/lab/answers.txt

echo "############################################################"
echo
echo "Lab Exercise"
echo
echo "************************************************************" 
echo
echo "What command would you type to see who you are logged in as?"
echo
echo "Type your answer and press enter"
read a1
echo "$a1" >> /root/lab/results.txt
clear
echo "What command would you type to see all users that are logged in?"
echo
echo "Type your answer and press enter"
read a2
echo "$a2" >> /root/lab/results.txt
clear
echo "What command would you type to list files and directories?"
echo
echo "Type your answer and press enter"
read a3
echo "$a3" >> /root/lab/results.txt
clear
echo "What command would you type to list files and directories in the long version, include the switch?"
echo
echo "Type your answer and press enter"
read a4
echo "$a4" >> /root/lab/results.txt
clear
echo "What command would you type to list files and directories that reveals all files, include the switch?"
echo
echo "Type your answer and press enter"
read a5
echo "$a5" >> /root/lab/results.txt
clear
echo "What command would you type to see what directory you are presently in?"
echo
echo "Type your answer and press enter"
read a6
echo "$a6" >> /root/lab/results.txt
clear
echo "What command and argument would you type to make a new file called newfile.txt?"
echo
echo "Type your answer and press enter"
read a7
echo "$a7" >> /root/lab/results.txt
clear
echo "What command and argument would you type to make a new directory called test?"
echo
echo "Type your answer and press enter"
read a8
echo "$a8" >> /root/lab/results.txt
clear
echo "What command and argument would you type to go to the root of the filesystem?"
echo
echo "Type your answer and press enter"
read a9
echo "$a9" >> /root/lab/results.txt
clear
echo "What command and argument would you type to view the man pages for the command ls?"
echo
echo "Type your answer and press enter"
read a10
echo "$a10" >> /root/lab/results.txt
echo "End of the Lab, press enter to see your results"
read a11
cat /root/lab/results.txt >> /root/lab/answers.txt
sleep 1
cat /root/lab/answers.txt
#EOF
